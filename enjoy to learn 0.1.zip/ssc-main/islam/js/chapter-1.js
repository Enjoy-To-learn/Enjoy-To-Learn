let questions = [
  {
    numb: 1,
    question: ")Choose the correct sentence:",
    answer: "(গ) All of it depends on you",
    options: [
    "(ক) All of it depend on you",
    "(খ) All of it are depending on you",
    "(গ) All of it depends on you",
    "(ঘ) All of it are depended on you."
    ]
},

  {
    "numb": 1,
    "question": "আমাদের দেশের নাম কি? ",
    "answer": "(1) বাংলাদেশ",
    "options": [
"(1) বাংলাদেশ",
"(2) ভারত",
"(3) পাক",
"(4) নোয়াখালি"
]
},

//heare is all questins


];