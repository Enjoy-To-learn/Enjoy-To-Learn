let questions = [
  {
    numb: 1,
    question: ")Choose the correct sentence:",
    answer: "(গ) All of it depends on you",
    options: [
    "(ক) All of it depend on you",
    "(খ) All of it are depending on you",
    "(গ) All of it depends on you",
    "(ঘ) All of it are depended on you."
    ]
},

//heare is all questins


];